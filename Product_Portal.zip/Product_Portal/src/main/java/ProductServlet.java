import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductServlet
 */
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Retrieve product details 
        String productid = request.getParameter("productid");
        String productName = request.getParameter("productName");
        String productColor = request.getParameter("productColor");
        String productPrice = request.getParameter("productPrice");

        // Set the product details as attributes 
        request.setAttribute("productid", productid);
        request.setAttribute("productName", productName);
        request.setAttribute("productColor", productColor);
        request.setAttribute("productPrice", productPrice);

        // Forward the request to the JSP to display
        request.getRequestDispatcher("productDetails.jsp").forward(request, response);
	}

}
